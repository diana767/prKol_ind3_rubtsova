﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Collections;

namespace massiv
{
    class Program
    {
        static void Main(string[] args)
        {
            if (File.Exists("array.txt"))
            {
                Array array = new Array();
                ArrayList arrayList = new ArrayList();
                int size = 0, index = 0, numb = 0, j = 0;
                bool h = false;
                string Minus = "", yesOrNo = "";
                do
                {
                    Console.Write("Введите размер массива: ");              
                        size = int.Parse(Console.ReadLine());
                }
                while (size <= 0 || size > 20);
                int[] mass = array.Size(size);
                for (int i = 0; i < mass.Length; i++)
                {
                    Console.Write($"{mass[i]} ");
                }
                StreamWriter r = File.CreateText("array.txt");
                for (int i = 0; i < mass.Length; i++)
                    r.WriteLine(mass[i]);
                r.Close();
                do
                {
                    Console.Write("\nВведите позицию элемента: ");
                     index = int.Parse(Console.ReadLine()) - 1;
                        if (index > mass.Length) Console.WriteLine("error");
                        if (index < 0) Console.WriteLine("error");                   
                }
                while (index < 0 || index > mass.Length);
                Console.WriteLine($"{array.Element(mass, index)}");
                 do
                 {
                    Console.Write("Введите позицию элемента, с которого начнём вывод массива");                    
                        index = int.Parse(Console.ReadLine()) - 1;
                        if (index > mass.Length) Console.WriteLine("error");
                        if (index < 0) Console.WriteLine("error");              
                }
                while (index < 0 || index > mass.Length);
                int[] m_supportive1 = array.ArrayOutput(mass, index);
                for (int i = 0; i < m_supportive1.Count(); i++)
                {
                    Console.Write($"{m_supportive1[i]} ");
                }
                do
                {
                    Console.Write("\nВведите число, на которое будем умножать массив: ");
                    try
                    {
                        numb = int.Parse(Console.ReadLine());
                        h = true;
                    }
                    catch
                    {
                        Console.WriteLine("Неверный формат данных");
                        h = false;
                    }

                }
                while (h == false);        
                int[] m_supportive2 = array.Multiplication(mass, numb);
                for (int i = 0; i < m_supportive2.Count(); i++)
                {
                    Console.Write($"{m_supportive2[i]} ");
                }           
                do
                {
                    Console.Write("\nВыберите действие (+/-): ");
                    Minus = Convert.ToString(Console.ReadLine());
                }
                while (!(Minus == "+" || Minus == "-"));
                int[] mass2 = array.Size(mass.Length);
                int[] mass_z = new int[mass.Length];
                StreamReader sr = File.OpenText("array.txt");
                while (!sr.EndOfStream)
                {
                    mass_z[j] = Convert.ToInt32(sr.ReadLine());
                    j++;
                }
                sr.Close();
                Console.Write("\nПервый массив: ");
                for (int i = 0; i < mass_z.Length; i++)
                {
                    Console.Write($"{mass_z[i]} ");
                }
                Console.Write("\nВторой массив: ");
                for (int i = 0; i < mass2.Length; i++)
                {
                    Console.Write($"{mass2[i]} ");
                }
                arrayList = array.Action(mass_z, mass2, Minus);
                Console.Write("\nНовый массив: ");
                foreach (object action in arrayList)
                {
                    Console.Write($"{action} ");
                }
            }
            else Console.WriteLine("error");

            Console.ReadKey();
        }
    }
}
